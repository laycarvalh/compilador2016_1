package sistema;


import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.misc.Interval;

import antlr.trabalhoFinalParte1BaseVisitor;
import antlr.trabalhoFinalParte1Parser;
import ast.AST;

public class T1Visitor extends trabalhoFinalParte1BaseVisitor<AST>{
    AST noClass, noDeclaracaoBody, noFuncaoBody, noPrincipalBody;
    
    @Override
    public AST visitBody(trabalhoFinalParte1Parser.BodyContext ctx){
        int i = 0;
        String classe = "class";
        noClass = new AST(classe);
        
        AST nomeClasse = new AST(ctx.ID().getText());
        nomeClasse.setLinha(ctx.ID().getSymbol().getLine());
        
        
        noClass.adicionaFilho(nomeClasse);
        
        noClass.setLinha(ctx.getStart().getLine());
        
        try{
            noDeclaracaoBody = visit(ctx.declaracao(i));
        }catch(NullPointerException e){
            noDeclaracaoBody = null;
        }
        while(noDeclaracaoBody != null){
            noClass.adicionaFilho(noDeclaracaoBody);
            i++;
            try{
                noDeclaracaoBody = visit(ctx.declaracao(i));
            }catch(NullPointerException e){
                noDeclaracaoBody = null;
            }      
        }
        
        i = 0;
        
        try{
            noFuncaoBody = visit(ctx.funcao(i));
        }catch(NullPointerException e){
            noFuncaoBody = null;
        }
        
        while(noFuncaoBody != null){
            noClass.adicionaFilho(noFuncaoBody);
            i++;
            try{
                noFuncaoBody = visit(ctx.funcao(i));
            }catch(NullPointerException e){
                noFuncaoBody = null;
            }
        }
        
        noPrincipalBody = visit(ctx.principal());
        noClass.adicionaFilho(noPrincipalBody);
        return noClass;
    }
    
    @Override
    public AST visitMain(trabalhoFinalParte1Parser.MainContext ctx){
        int i = 0;
        AST noMain = new AST("main");
        
        
        noMain.setLinha(ctx.getStart().getLine());
        
        AST declaracao, comandos;
        try{
            declaracao = visit(ctx.declaracao(i));
        }catch(NullPointerException e){
            declaracao = null;
        }
        while (declaracao != null){
            noMain.adicionaFilho(declaracao);
            i++;
            try{
                declaracao = visit(ctx.declaracao(i));
            }catch(NullPointerException e){
                declaracao = null;
            }
        }
        
        i = 0;
        
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        while (comandos != null){
            noMain.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        
        return noMain;
    }
    
    @Override
    public AST visitDeclaracaoVariaveis(trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx){
    	
    	return visit(ctx.declaracao_var());
    }
    
    @Override
    public AST visitVariaveis(trabalhoFinalParte1Parser.VariaveisContext ctx){
        AST noVariavel = new AST("var");
        
        noVariavel.setLinha(ctx.getStart().getLine());
        
        AST noTipo = visit(ctx.tipo());
        noVariavel.adicionaFilho(noTipo);
        AST noListaIds = visit(ctx.lista_ids());
        noVariavel.adicionaFilho(noListaIds);
        
        return noVariavel;
    }
    
    @Override
    public AST visitTipoInt(trabalhoFinalParte1Parser.TipoIntContext ctx){
        AST noTipoInt = new AST("int");
        
        noTipoInt.setLinha(ctx.getStart().getLine());
        
        return noTipoInt;
    }
    
    @Override
    public AST visitTipoFloat(trabalhoFinalParte1Parser.TipoFloatContext ctx){
        AST noTipoFloat = new AST("float");
        
        noTipoFloat.setLinha(ctx.getStart().getLine());
        
        return noTipoFloat;
    }
    
    @Override
    public AST visitTipoString(trabalhoFinalParte1Parser.TipoStringContext ctx){
        AST noTipoString = new AST("string");
        
        noTipoString.setLinha(ctx.getStart().getLine());
        
        return noTipoString;
    }
    
    @Override
    public AST visitTipoBoolean(trabalhoFinalParte1Parser.TipoBooleanContext ctx){
        AST noTipoBoolean = new AST("boolean");
        
        noTipoBoolean.setLinha(ctx.getStart().getLine());
        
        return noTipoBoolean;
    }
    
    @Override
    public AST visitListaIds(trabalhoFinalParte1Parser.ListaIdsContext ctx){
        AST noListaIds = new AST(",");
        
        noListaIds.setLinha(ctx.getStart().getLine());
        
        AST id = new AST(ctx.ID().getText());
        
        id.setLinha(ctx.ID().getSymbol().getLine());
        
        noListaIds.adicionaFilho(id);
        AST listaIds = visit(ctx.lista_ids());
        
        noListaIds.adicionaFilho(listaIds);
        return noListaIds;
    }
    
    @Override
    public AST visitListaIdsID(trabalhoFinalParte1Parser.ListaIdsIDContext ctx){
        AST noID = new AST(ctx.ID().getText());
        noID.setLinha(ctx.ID().getSymbol().getLine());
        return noID;
    }
    
    @Override
    public AST visitDeclaracaoContantes(trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx){
        return visit(ctx.declaracao_const());
    }
    
    @Override
    public AST visitContantes(trabalhoFinalParte1Parser.ContantesContext ctx){
        AST noConstante = new AST("const");
        
        noConstante.setLinha(ctx.getStart().getLine());
        
        AST nomeConstante = new AST(ctx.ID().getText());
        
        nomeConstante.setLinha(ctx.ID().getSymbol().getLine());
        
        noConstante.adicionaFilho(nomeConstante);
        AST tipo = visit(ctx.tipo());
        AST valor = null;
        if(ctx.BOOLEAN() != null){
            valor = new AST(ctx.BOOLEAN().getText());
            valor.setLinha(ctx.BOOLEAN().getSymbol().getLine());
        }else if(ctx.NUM() != null){
            valor = new AST(ctx.NUM().getText());
            valor.setLinha(ctx.NUM().getSymbol().getLine());
        }else{
            valor = new AST(ctx.STRING().getText());
            valor.setLinha(ctx.STRING().getSymbol().getLine());
        }
        noConstante.adicionaFilho(tipo);
        noConstante.adicionaFilho(valor);
        return noConstante;
    }
    
    @Override
    public AST visitFunction(trabalhoFinalParte1Parser.FunctionContext ctx){
        int i = 0;
        AST declaracao;
        AST comandos;
                
        AST noFuncao = new AST("function");
        
        noFuncao.setLinha(ctx.getStart().getLine());
        
        AST nomeFuncao = new AST(ctx.ID().getText());
        nomeFuncao.setLinha(ctx.ID().getSymbol().getLine());
        
        noFuncao.adicionaFilho(nomeFuncao);
        
        AST listaParam = visit(ctx.lista_de_parametros());
        AST param = new AST("param");
        param.adicionaFilho(listaParam);
        noFuncao.adicionaFilho(param);
        
        AST tipo = visit(ctx.tipo());
        noFuncao.adicionaFilho(tipo);
        
        try{
            declaracao = visit(ctx.declaracao(i));
        }catch(NullPointerException e){
            declaracao = null;
        }
        while (declaracao != null){
            noFuncao.adicionaFilho(declaracao);
            i++;
            try{
                declaracao = visit(ctx.declaracao(i));
            }catch(NullPointerException e){
                declaracao = null;
            }
        }
        i = 0;
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        while (comandos != null){
            noFuncao.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        return noFuncao;
    }
    
    @Override
    public AST visitListaParam(trabalhoFinalParte1Parser.ListaParamContext ctx){
        AST noListaParam = new AST(",");
        
        noListaParam.setLinha(ctx.getStart().getLine());
        
        AST parametro = visit(ctx.parametro());
        AST listaParametro = visit(ctx.lista_de_parametros());
        noListaParam.adicionaFilho(parametro);
        noListaParam.adicionaFilho(listaParametro);
        return noListaParam;
    }
    
    @Override
    public AST visitParam(trabalhoFinalParte1Parser.ParamContext ctx){
        return visit(ctx.parametro());
    }
    
    @Override
    public AST visitEmptyParam(trabalhoFinalParte1Parser.EmptyParamContext ctx){
        AST noVazio = new AST("");
        
        noVazio.setLinha(ctx.getStart().getLine());
        
        return noVazio;
    }
    
    @Override
    public AST visitParameter(trabalhoFinalParte1Parser.ParameterContext ctx){
        AST noTipo = visit(ctx.tipo());
        AST noID = new AST(ctx.ID().getText());
        noID.setLinha(ctx.ID().getSymbol().getLine());
        noTipo.adicionaFilho(noID);
        return noTipo;
    }
    
    @Override
    public AST visitComandoPrint(trabalhoFinalParte1Parser.ComandoPrintContext ctx){
        AST print = new AST("print");
        
        print.setLinha(ctx.getStart().getLine());
        
        AST listaExpr = visit(ctx.lista_de_expr());
        print.adicionaFilho(listaExpr);
        return print;
    }
    
    @Override
    public AST visitListExpression(trabalhoFinalParte1Parser.ListExpressionContext ctx){
        AST noListExpr = new AST(",");
        
        noListExpr.setLinha(ctx.getStart().getLine());
        
        AST expr = visit(ctx.expr());
        noListExpr.adicionaFilho(expr);
        AST listExpr = visit(ctx.lista_de_expr());
        noListExpr.adicionaFilho(listExpr);
        return noListExpr;
    }
    
    @Override
    public AST visitEmptyExpression(trabalhoFinalParte1Parser.EmptyExpressionContext ctx){
        AST noVazio = new AST("");

        noVazio.setLinha(ctx.getStart().getLine());
        
        return noVazio;
    }
    
    @Override
    public AST visitExpression(trabalhoFinalParte1Parser.ExpressionContext ctx){
        return visit(ctx.expr());
    }
    
    @Override
    public AST visitExprParentese(trabalhoFinalParte1Parser.ExprParenteseContext ctx){
        return visit(ctx.parentese());
    }
    
    @Override
    public AST visitParens(trabalhoFinalParte1Parser.ParensContext ctx){
        return visit(ctx.expr());
    }
    
    @Override
    public AST visitFat(trabalhoFinalParte1Parser.FatContext ctx){
        return visit(ctx.fator());
    }
    
    @Override
    public AST visitFatorNumero(trabalhoFinalParte1Parser.FatorNumeroContext ctx){
        return visit(ctx.numero());
    }
    
    @Override
    public AST visitNumber(trabalhoFinalParte1Parser.NumberContext ctx){
        AST noNumero = new AST(ctx.NUM().getText());
        noNumero.setLinha(ctx.NUM().getSymbol().getLine());
        return noNumero;
    }
    
    @Override
    public AST visitFatorBoolean(trabalhoFinalParte1Parser.FatorBooleanContext ctx){
        AST noBoolean = new AST(ctx.BOOLEAN().getText());
        noBoolean.setLinha(ctx.BOOLEAN().getSymbol().getLine());
        return noBoolean;
    } 
    
    @Override
    public AST visitFatorString(trabalhoFinalParte1Parser.FatorStringContext ctx){
        AST noString = new AST(ctx.STRING().getText());
        noString.setLinha(ctx.STRING().getSymbol().getLine());
        return noString;
    }
    
    @Override
    public AST visitFatorIdentificador(trabalhoFinalParte1Parser.FatorIdentificadorContext ctx){
        return visit(ctx.identificador());
    }
    
    @Override
    public AST visitId(trabalhoFinalParte1Parser.IdContext ctx){
        AST noId = new AST(ctx.ID().getText());
        noId.setLinha(ctx.ID().getSymbol().getLine());
        return noId;
    }
    
    @Override
    public AST visitFatorChamadaFuncaoAninhada(trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx){
        return visit(ctx.chamada_de_funcao_aninhada());
    }
    
    @Override
    public AST visitChamadaFuncaoAninhada(trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx){
        AST noChamadaFuncao = new AST("chamada_funcao");
        AST nomeFuncao= new AST(ctx.ID().getText());
        noChamadaFuncao.adicionaFilho(nomeFuncao);
        noChamadaFuncao.setLinha(ctx.ID().getSymbol().getLine());
        AST listaExpr = visit(ctx.lista_de_expr());
        noChamadaFuncao.adicionaFilho(listaExpr);
        return noChamadaFuncao;
    }
    
    @Override
    public AST visitExprNot(trabalhoFinalParte1Parser.ExprNotContext ctx){
        AST not = new AST("!");
        not.setLinha(ctx.getStart().getLine());
        AST opnot = visit(ctx.opnot());
        not.adicionaFilho(opnot);
        return not;
    }
    
    @Override
    public AST visitOpnotRelacional(trabalhoFinalParte1Parser.OpnotRelacionalContext ctx){
    	return visit(ctx.oprelacional());
    }
    
    @Override
    public AST visitOpnotFator(trabalhoFinalParte1Parser.OpnotFatorContext ctx){
    	return visit(ctx.fator());
    }
    
    @Override
    public AST visitExprMinus(trabalhoFinalParte1Parser.ExprMinusContext ctx){
        AST minus = new AST("-");
        minus.setLinha(ctx.getStart().getLine());
        AST expr = visit(ctx.expr());
        minus.adicionaFilho(expr);
        return minus;
    }
    
    @Override
    public AST visitExprMultdiv(trabalhoFinalParte1Parser.ExprMultdivContext ctx){
        AST mult_div = new AST(ctx.s.getText());
        mult_div.setLinha(ctx.s.getLine());
        AST expr1 = visit(ctx.expr(0));
        AST expr2 = visit(ctx.expr(1));
        mult_div.adicionaFilho(expr1);
        mult_div.adicionaFilho(expr2);
        return mult_div;
    }
    
    @Override
    public AST visitExprSomasub(trabalhoFinalParte1Parser.ExprSomasubContext ctx){
        AST soma_sub = new AST(ctx.s.getText());
        soma_sub.setLinha(ctx.s.getLine());
        AST expr1 = visit(ctx.expr(0));
        AST expr2 = visit(ctx.expr(1));
        soma_sub.adicionaFilho(expr1);
        soma_sub.adicionaFilho(expr2);
        return soma_sub;
    }
    
    @Override
    public AST visitComandoAtribuicao(trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx){
        return visit(ctx.atribuicao());
    }
    
    @Override
    public AST visitAtribution(trabalhoFinalParte1Parser.AtributionContext ctx){
        AST noAtribuicao = new AST("=");
        noAtribuicao.setLinha(ctx.getStart().getLine());
        AST ID = new AST(ctx.ID().getText());
        ID.setLinha(ctx.ID().getSymbol().getLine());
        noAtribuicao.adicionaFilho(ID);
        AST expr = visit(ctx.expr());
        noAtribuicao.adicionaFilho(expr);
        return noAtribuicao;
    }
    
    @Override
    public AST visitComandoExit(trabalhoFinalParte1Parser.ComandoExitContext ctx){
        AST noExit = new AST("exit");
        noExit.setLinha(ctx.getStart().getLine());
        return noExit;
    }
    
    @Override
    public AST visitComadoRead(trabalhoFinalParte1Parser.ComadoReadContext ctx){
        AST noRead = new AST("read");
        noRead.setLinha(ctx.getStart().getLine());
        AST listaIds = visit(ctx.lista_ids());
        noRead.adicionaFilho(listaIds);
        return noRead;
    }
    
    @Override
    public AST visitComandoChamadaFuncao(trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx){
        return visit(ctx.chamada_de_funcao());
    }
    
    @Override
    public AST visitChamadaFuncao(trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx){
    	AST noChamadaFuncao = new AST("chamada_funcao");
        AST nomeFuncao= new AST(ctx.ID().getText());
        noChamadaFuncao.adicionaFilho(nomeFuncao);
        noChamadaFuncao.setLinha(ctx.ID().getSymbol().getLine());
        AST listaExpr = visit(ctx.lista_de_expr());
        noChamadaFuncao.adicionaFilho(listaExpr);
        return noChamadaFuncao;
    }
    
    @Override
    public AST visitComandoRetorno(trabalhoFinalParte1Parser.ComandoRetornoContext ctx){
        return visit(ctx.retorno());
    }
    
    @Override
    public AST visitReturn(trabalhoFinalParte1Parser.ReturnContext ctx){
        AST noRetorno = new AST("return");
        noRetorno.setLinha(ctx.getStart().getLine());
        AST expr = visit(ctx.expr());
        noRetorno.adicionaFilho(expr);
        return noRetorno;
    }
    
    @Override
    public AST visitComandoControle(trabalhoFinalParte1Parser.ComandoControleContext ctx){
        return visit(ctx.comandos_controle());
    }
    
    @Override
    public AST visitComandoControleIf(trabalhoFinalParte1Parser.ComandoControleIfContext ctx){
        int i = 0;
        AST comandos;
        AST comando_else;
        AST noIf = new AST("if");
        noIf.setLinha(ctx.getStart().getLine());
        AST oprelacional = visit(ctx.oprelacional());
        noIf.adicionaFilho(oprelacional);
        
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        
        while (comandos != null){
            noIf.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        try{
        	comando_else = visit(ctx.comando_else());
        }catch(Exception e){
        	comando_else = null;
        }
        
        if(comando_else != null)
            noIf.adicionaFilho(comando_else);

        return noIf;
    }
    
    @Override
    public AST visitControleElse(trabalhoFinalParte1Parser.ControleElseContext ctx){
        int i = 0;
        AST noElse = new AST("else");
        noElse.setLinha(ctx.getStart().getLine());
        AST comandos;
        
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        
        while(comandos != null){
            noElse.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        
        return noElse;
    }
    
    @Override
    public AST visitOperadorRelacional(trabalhoFinalParte1Parser.OperadorRelacionalContext ctx){
        AST noRelacional = new AST(ctx.s.getText());
        noRelacional.setLinha(ctx.s.getLine());
        AST expr1 = visit(ctx.v1);
        AST expr2 = visit(ctx.v2);
        noRelacional.adicionaFilho(expr1);
        noRelacional.adicionaFilho(expr2);
        return noRelacional;
    }
    
    @Override
    public AST visitOperadorRelacionalExpr(trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx){
        return visit(ctx.opnot());
    }
    
    @Override
    public AST visitComandoControleWhile(trabalhoFinalParte1Parser.ComandoControleWhileContext ctx){
        int i = 0;
        AST Comandowhile = new AST("while");
        Comandowhile.setLinha(ctx.getStart().getLine());
        AST oprelacional = visit(ctx.oprelacional());
        Comandowhile.adicionaFilho(oprelacional);
        
        AST comandos;
        
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        
        while(comandos != null){
            Comandowhile.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        return Comandowhile;
    }
    
    @Override
    public AST visitComandoControleFor(trabalhoFinalParte1Parser.ComandoControleForContext ctx){
        int i = 0;
        AST noFor = new AST("for");
        noFor.setLinha(ctx.getStart().getLine());
        AST valorInicial = new AST("valor_inicial");
        valorInicial.setLinha(ctx.getStart().getLine());
        
        AST valorFinal = new AST("valor_final");
        valorFinal.setLinha(ctx.getStart().getLine());
        
        AST identificador = visit(ctx.identificador());
        AST numero1 = visit(ctx.numero(0));
        AST numero2 = visit(ctx.numero(1));
        AST noStepFor;
        try{
        	noStepFor = visit(ctx.step_for());
        }catch(Exception e){
        	noStepFor = null;
        }
        
        
        valorInicial.adicionaFilho(identificador);
        valorInicial.adicionaFilho(numero1);
        
        valorFinal.adicionaFilho(numero2);
        
        noFor.adicionaFilho(valorInicial);
        noFor.adicionaFilho(valorFinal);
        
        
        if(noStepFor != null) noFor.adicionaFilho(noStepFor);
        
        AST comandos;
        try{
            comandos = visit(ctx.comandos(i));
        }catch(NullPointerException e){
            comandos = null;
        }
        
        while(comandos != null){
            noFor.adicionaFilho(comandos);
            i++;
            try{
                comandos = visit(ctx.comandos(i));
            }catch(NullPointerException e){
                comandos = null;
            }
        }
        
        return noFor;
    }
    
    @Override
    public AST visitStepFor(trabalhoFinalParte1Parser.StepForContext ctx){
        AST step = new AST("step");
        step.setLinha(ctx.getStart().getLine());
        AST numero = visit(ctx.numero());
        step.adicionaFilho(numero);
        return step;
    }
    
    public AST getAST(){
        return noClass;
    }
}
