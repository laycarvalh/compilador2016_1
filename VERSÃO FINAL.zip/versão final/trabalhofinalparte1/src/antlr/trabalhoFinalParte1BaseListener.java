package antlr;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

/**
 * This class provides an empty implementation of {@link trabalhoFinalParte1Listener},
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
public class trabalhoFinalParte1BaseListener implements trabalhoFinalParte1Listener {
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterControleElse(@NotNull trabalhoFinalParte1Parser.ControleElseContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitControleElse(@NotNull trabalhoFinalParte1Parser.ControleElseContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterTipoString(@NotNull trabalhoFinalParte1Parser.TipoStringContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitTipoString(@NotNull trabalhoFinalParte1Parser.TipoStringContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComadoRead(@NotNull trabalhoFinalParte1Parser.ComadoReadContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComadoRead(@NotNull trabalhoFinalParte1Parser.ComadoReadContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterContantes(@NotNull trabalhoFinalParte1Parser.ContantesContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitContantes(@NotNull trabalhoFinalParte1Parser.ContantesContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterOpnotRelacional(@NotNull trabalhoFinalParte1Parser.OpnotRelacionalContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitOpnotRelacional(@NotNull trabalhoFinalParte1Parser.OpnotRelacionalContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterOpnotFator(@NotNull trabalhoFinalParte1Parser.OpnotFatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitOpnotFator(@NotNull trabalhoFinalParte1Parser.OpnotFatorContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterTipoBoolean(@NotNull trabalhoFinalParte1Parser.TipoBooleanContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitTipoBoolean(@NotNull trabalhoFinalParte1Parser.TipoBooleanContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterBody(@NotNull trabalhoFinalParte1Parser.BodyContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitBody(@NotNull trabalhoFinalParte1Parser.BodyContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterParens(@NotNull trabalhoFinalParte1Parser.ParensContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitParens(@NotNull trabalhoFinalParte1Parser.ParensContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterParam(@NotNull trabalhoFinalParte1Parser.ParamContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitParam(@NotNull trabalhoFinalParte1Parser.ParamContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterListaIds(@NotNull trabalhoFinalParte1Parser.ListaIdsContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitListaIds(@NotNull trabalhoFinalParte1Parser.ListaIdsContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterNumber(@NotNull trabalhoFinalParte1Parser.NumberContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitNumber(@NotNull trabalhoFinalParte1Parser.NumberContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFatorNumero(@NotNull trabalhoFinalParte1Parser.FatorNumeroContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFatorNumero(@NotNull trabalhoFinalParte1Parser.FatorNumeroContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterStepFor(@NotNull trabalhoFinalParte1Parser.StepForContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitStepFor(@NotNull trabalhoFinalParte1Parser.StepForContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoControleFor(@NotNull trabalhoFinalParte1Parser.ComandoControleForContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoControleFor(@NotNull trabalhoFinalParte1Parser.ComandoControleForContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFatorIdentificador(@NotNull trabalhoFinalParte1Parser.FatorIdentificadorContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFatorIdentificador(@NotNull trabalhoFinalParte1Parser.FatorIdentificadorContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFatorBoolean(@NotNull trabalhoFinalParte1Parser.FatorBooleanContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFatorBoolean(@NotNull trabalhoFinalParte1Parser.FatorBooleanContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterReturn(@NotNull trabalhoFinalParte1Parser.ReturnContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitReturn(@NotNull trabalhoFinalParte1Parser.ReturnContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExprNot(@NotNull trabalhoFinalParte1Parser.ExprNotContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExprNot(@NotNull trabalhoFinalParte1Parser.ExprNotContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterId(@NotNull trabalhoFinalParte1Parser.IdContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitId(@NotNull trabalhoFinalParte1Parser.IdContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterListaParam(@NotNull trabalhoFinalParte1Parser.ListaParamContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitListaParam(@NotNull trabalhoFinalParte1Parser.ListaParamContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterOperadorRelacional(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitOperadorRelacional(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoAtribuicao(@NotNull trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoAtribuicao(@NotNull trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterTipoInt(@NotNull trabalhoFinalParte1Parser.TipoIntContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitTipoInt(@NotNull trabalhoFinalParte1Parser.TipoIntContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExprSomasub(@NotNull trabalhoFinalParte1Parser.ExprSomasubContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExprSomasub(@NotNull trabalhoFinalParte1Parser.ExprSomasubContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterListaIdsID(@NotNull trabalhoFinalParte1Parser.ListaIdsIDContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitListaIdsID(@NotNull trabalhoFinalParte1Parser.ListaIdsIDContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoRetorno(@NotNull trabalhoFinalParte1Parser.ComandoRetornoContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoRetorno(@NotNull trabalhoFinalParte1Parser.ComandoRetornoContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoControleWhile(@NotNull trabalhoFinalParte1Parser.ComandoControleWhileContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoControleWhile(@NotNull trabalhoFinalParte1Parser.ComandoControleWhileContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFatorString(@NotNull trabalhoFinalParte1Parser.FatorStringContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFatorString(@NotNull trabalhoFinalParte1Parser.FatorStringContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterMain(@NotNull trabalhoFinalParte1Parser.MainContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitMain(@NotNull trabalhoFinalParte1Parser.MainContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoControle(@NotNull trabalhoFinalParte1Parser.ComandoControleContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoControle(@NotNull trabalhoFinalParte1Parser.ComandoControleContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterDeclaracaoVariaveis(@NotNull trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitDeclaracaoVariaveis(@NotNull trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterTipoFloat(@NotNull trabalhoFinalParte1Parser.TipoFloatContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitTipoFloat(@NotNull trabalhoFinalParte1Parser.TipoFloatContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterEmptyParam(@NotNull trabalhoFinalParte1Parser.EmptyParamContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitEmptyParam(@NotNull trabalhoFinalParte1Parser.EmptyParamContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExpression(@NotNull trabalhoFinalParte1Parser.ExpressionContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExpression(@NotNull trabalhoFinalParte1Parser.ExpressionContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoExit(@NotNull trabalhoFinalParte1Parser.ComandoExitContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoExit(@NotNull trabalhoFinalParte1Parser.ComandoExitContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterParameter(@NotNull trabalhoFinalParte1Parser.ParameterContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitParameter(@NotNull trabalhoFinalParte1Parser.ParameterContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFat(@NotNull trabalhoFinalParte1Parser.FatContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFat(@NotNull trabalhoFinalParte1Parser.FatContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoControleIf(@NotNull trabalhoFinalParte1Parser.ComandoControleIfContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoControleIf(@NotNull trabalhoFinalParte1Parser.ComandoControleIfContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFunction(@NotNull trabalhoFinalParte1Parser.FunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFunction(@NotNull trabalhoFinalParte1Parser.FunctionContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterDeclaracaoContantes(@NotNull trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitDeclaracaoContantes(@NotNull trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterOperadorRelacionalExpr(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitOperadorRelacionalExpr(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterFatorChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitFatorChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExprMinus(@NotNull trabalhoFinalParte1Parser.ExprMinusContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExprMinus(@NotNull trabalhoFinalParte1Parser.ExprMinusContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterComandoPrint(@NotNull trabalhoFinalParte1Parser.ComandoPrintContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitComandoPrint(@NotNull trabalhoFinalParte1Parser.ComandoPrintContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterEmptyExpression(@NotNull trabalhoFinalParte1Parser.EmptyExpressionContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitEmptyExpression(@NotNull trabalhoFinalParte1Parser.EmptyExpressionContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterAtribution(@NotNull trabalhoFinalParte1Parser.AtributionContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitAtribution(@NotNull trabalhoFinalParte1Parser.AtributionContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExprMultdiv(@NotNull trabalhoFinalParte1Parser.ExprMultdivContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExprMultdiv(@NotNull trabalhoFinalParte1Parser.ExprMultdivContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterListExpression(@NotNull trabalhoFinalParte1Parser.ListExpressionContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitListExpression(@NotNull trabalhoFinalParte1Parser.ListExpressionContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterExprParentese(@NotNull trabalhoFinalParte1Parser.ExprParenteseContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitExprParentese(@NotNull trabalhoFinalParte1Parser.ExprParenteseContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterVariaveis(@NotNull trabalhoFinalParte1Parser.VariaveisContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitVariaveis(@NotNull trabalhoFinalParte1Parser.VariaveisContext ctx) { }

	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void enterEveryRule(@NotNull ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void exitEveryRule(@NotNull ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void visitTerminal(@NotNull TerminalNode node) { }
	/**
	 * {@inheritDoc}
	 * <p/>
	 * The default implementation does nothing.
	 */
	@Override public void visitErrorNode(@NotNull ErrorNode node) { }
}