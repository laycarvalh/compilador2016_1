package antlr;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class trabalhoFinalParte1Parser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__34=1, T__33=2, T__32=3, T__31=4, T__30=5, T__29=6, T__28=7, T__27=8, 
		T__26=9, T__25=10, T__24=11, T__23=12, T__22=13, T__21=14, T__20=15, T__19=16, 
		T__18=17, T__17=18, T__16=19, T__15=20, T__14=21, T__13=22, T__12=23, 
		T__11=24, T__10=25, T__9=26, T__8=27, T__7=28, T__6=29, T__5=30, T__4=31, 
		T__3=32, T__2=33, T__1=34, T__0=35, Tmain=36, STRING=37, BOOLEAN=38, ID=39, 
		NUM=40, WS=41, LINE_COMMENT=42, COMMENT=43;
	public static final String[] tokenNames = {
		"<INVALID>", "'read'", "','", "'while'", "'exit'", "'-'", "'*'", "'('", 
		"':'", "'if'", "'int'", "'<'", "'!='", "'var'", "'<='", "'{'", "'else'", 
		"'boolean'", "'}'", "'float'", "')'", "'step'", "'+'", "'for'", "'print'", 
		"'<>'", "'='", "'return'", "';'", "'>'", "'string'", "'/'", "'=='", "'class'", 
		"'>='", "'!'", "'main'", "STRING", "BOOLEAN", "ID", "NUM", "WS", "LINE_COMMENT", 
		"COMMENT"
	};
	public static final int
		RULE_prog = 0, RULE_principal = 1, RULE_funcao = 2, RULE_declaracao = 3, 
		RULE_retorno = 4, RULE_lista_de_parametros = 5, RULE_lista_de_expr = 6, 
		RULE_parametro = 7, RULE_tipo = 8, RULE_comandos = 9, RULE_chamada_de_funcao = 10, 
		RULE_chamada_de_funcao_aninhada = 11, RULE_comando_else = 12, RULE_step_for = 13, 
		RULE_comandos_controle = 14, RULE_atribuicao = 15, RULE_declaracao_var = 16, 
		RULE_declaracao_const = 17, RULE_lista_ids = 18, RULE_expr = 19, RULE_opnot = 20, 
		RULE_oprelacional = 21, RULE_parentese = 22, RULE_fator = 23, RULE_numero = 24, 
		RULE_identificador = 25;
	public static final String[] ruleNames = {
		"prog", "principal", "funcao", "declaracao", "retorno", "lista_de_parametros", 
		"lista_de_expr", "parametro", "tipo", "comandos", "chamada_de_funcao", 
		"chamada_de_funcao_aninhada", "comando_else", "step_for", "comandos_controle", 
		"atribuicao", "declaracao_var", "declaracao_const", "lista_ids", "expr", 
		"opnot", "oprelacional", "parentese", "fator", "numero", "identificador"
	};

	@Override
	public String getGrammarFileName() { return "trabalhoFinalParte1.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public trabalhoFinalParte1Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgContext extends ParserRuleContext {
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
	 
		public ProgContext() { }
		public void copyFrom(ProgContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BodyContext extends ProgContext {
		public DeclaracaoContext declaracao(int i) {
			return getRuleContext(DeclaracaoContext.class,i);
		}
		public FuncaoContext funcao(int i) {
			return getRuleContext(FuncaoContext.class,i);
		}
		public List<DeclaracaoContext> declaracao() {
			return getRuleContexts(DeclaracaoContext.class);
		}
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public List<FuncaoContext> funcao() {
			return getRuleContexts(FuncaoContext.class);
		}
		public PrincipalContext principal() {
			return getRuleContext(PrincipalContext.class,0);
		}
		public BodyContext(ProgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterBody(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitBody(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitBody(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			_localctx = new BodyContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(52); match(33);
			setState(53); match(ID);
			setState(54); match(28);
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 10) | (1L << 13) | (1L << 17) | (1L << 19) | (1L << 30))) != 0)) {
				{
				{
				setState(55); declaracao();
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(64);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID) {
				{
				{
				setState(61); funcao();
				}
				}
				setState(66);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(67); principal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrincipalContext extends ParserRuleContext {
		public PrincipalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_principal; }
	 
		public PrincipalContext() { }
		public void copyFrom(PrincipalContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class MainContext extends PrincipalContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public DeclaracaoContext declaracao(int i) {
			return getRuleContext(DeclaracaoContext.class,i);
		}
		public List<DeclaracaoContext> declaracao() {
			return getRuleContexts(DeclaracaoContext.class);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public MainContext(PrincipalContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterMain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitMain(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitMain(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrincipalContext principal() throws RecognitionException {
		PrincipalContext _localctx = new PrincipalContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_principal);
		int _la;
		try {
			_localctx = new MainContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(69); match(Tmain);
			setState(70); match(7);
			setState(71); match(20);
			setState(72); match(15);
			setState(76);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 10) | (1L << 13) | (1L << 17) | (1L << 19) | (1L << 30))) != 0)) {
				{
				{
				setState(73); declaracao();
				}
				}
				setState(78);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(80); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(79); comandos();
				}
				}
				setState(82); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0) );
			setState(84); match(18);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncaoContext extends ParserRuleContext {
		public FuncaoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcao; }
	 
		public FuncaoContext() { }
		public void copyFrom(FuncaoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class FunctionContext extends FuncaoContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public DeclaracaoContext declaracao(int i) {
			return getRuleContext(DeclaracaoContext.class,i);
		}
		public List<DeclaracaoContext> declaracao() {
			return getRuleContexts(DeclaracaoContext.class);
		}
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public Lista_de_parametrosContext lista_de_parametros() {
			return getRuleContext(Lista_de_parametrosContext.class,0);
		}
		public FunctionContext(FuncaoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FuncaoContext funcao() throws RecognitionException {
		FuncaoContext _localctx = new FuncaoContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_funcao);
		int _la;
		try {
			_localctx = new FunctionContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(86); match(ID);
			setState(87); match(7);
			setState(88); lista_de_parametros();
			setState(89); match(20);
			setState(90); match(8);
			setState(91); tipo();
			setState(92); match(15);
			setState(96);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 10) | (1L << 13) | (1L << 17) | (1L << 19) | (1L << 30))) != 0)) {
				{
				{
				setState(93); declaracao();
				}
				}
				setState(98);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(102);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0)) {
				{
				{
				setState(99); comandos();
				}
				}
				setState(104);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(105); match(18);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclaracaoContext extends ParserRuleContext {
		public DeclaracaoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaracao; }
	 
		public DeclaracaoContext() { }
		public void copyFrom(DeclaracaoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class DeclaracaoVariaveisContext extends DeclaracaoContext {
		public Declaracao_varContext declaracao_var() {
			return getRuleContext(Declaracao_varContext.class,0);
		}
		public DeclaracaoVariaveisContext(DeclaracaoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterDeclaracaoVariaveis(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitDeclaracaoVariaveis(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitDeclaracaoVariaveis(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DeclaracaoContantesContext extends DeclaracaoContext {
		public Declaracao_constContext declaracao_const() {
			return getRuleContext(Declaracao_constContext.class,0);
		}
		public DeclaracaoContantesContext(DeclaracaoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterDeclaracaoContantes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitDeclaracaoContantes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitDeclaracaoContantes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclaracaoContext declaracao() throws RecognitionException {
		DeclaracaoContext _localctx = new DeclaracaoContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_declaracao);
		try {
			setState(109);
			switch (_input.LA(1)) {
			case 13:
				_localctx = new DeclaracaoVariaveisContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(107); declaracao_var();
				}
				break;
			case 10:
			case 17:
			case 19:
			case 30:
				_localctx = new DeclaracaoContantesContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(108); declaracao_const();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RetornoContext extends ParserRuleContext {
		public RetornoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_retorno; }
	 
		public RetornoContext() { }
		public void copyFrom(RetornoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ReturnContext extends RetornoContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ReturnContext(RetornoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterReturn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitReturn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitReturn(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RetornoContext retorno() throws RecognitionException {
		RetornoContext _localctx = new RetornoContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_retorno);
		try {
			_localctx = new ReturnContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(111); match(27);
			setState(112); match(7);
			setState(113); expr(0);
			setState(114); match(20);
			setState(115); match(28);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Lista_de_parametrosContext extends ParserRuleContext {
		public Lista_de_parametrosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lista_de_parametros; }
	 
		public Lista_de_parametrosContext() { }
		public void copyFrom(Lista_de_parametrosContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParamContext extends Lista_de_parametrosContext {
		public ParametroContext parametro() {
			return getRuleContext(ParametroContext.class,0);
		}
		public ParamContext(Lista_de_parametrosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class EmptyParamContext extends Lista_de_parametrosContext {
		public EmptyParamContext(Lista_de_parametrosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterEmptyParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitEmptyParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitEmptyParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ListaParamContext extends Lista_de_parametrosContext {
		public ParametroContext parametro() {
			return getRuleContext(ParametroContext.class,0);
		}
		public Lista_de_parametrosContext lista_de_parametros() {
			return getRuleContext(Lista_de_parametrosContext.class,0);
		}
		public ListaParamContext(Lista_de_parametrosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterListaParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitListaParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitListaParam(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Lista_de_parametrosContext lista_de_parametros() throws RecognitionException {
		Lista_de_parametrosContext _localctx = new Lista_de_parametrosContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_lista_de_parametros);
		try {
			setState(123);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				_localctx = new ListaParamContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(117); parametro();
				setState(118); match(2);
				setState(119); lista_de_parametros();
				}
				break;

			case 2:
				_localctx = new ParamContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(121); parametro();
				}
				break;

			case 3:
				_localctx = new EmptyParamContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Lista_de_exprContext extends ParserRuleContext {
		public Lista_de_exprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lista_de_expr; }
	 
		public Lista_de_exprContext() { }
		public void copyFrom(Lista_de_exprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class EmptyExpressionContext extends Lista_de_exprContext {
		public EmptyExpressionContext(Lista_de_exprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterEmptyExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitEmptyExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitEmptyExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExpressionContext extends Lista_de_exprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExpressionContext(Lista_de_exprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ListExpressionContext extends Lista_de_exprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Lista_de_exprContext lista_de_expr() {
			return getRuleContext(Lista_de_exprContext.class,0);
		}
		public ListExpressionContext(Lista_de_exprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterListExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitListExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitListExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Lista_de_exprContext lista_de_expr() throws RecognitionException {
		Lista_de_exprContext _localctx = new Lista_de_exprContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_lista_de_expr);
		try {
			setState(131);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				_localctx = new ListExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(125); expr(0);
				setState(126); match(2);
				setState(127); lista_de_expr();
				}
				break;

			case 2:
				_localctx = new ExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(129); expr(0);
				}
				break;

			case 3:
				_localctx = new EmptyExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParametroContext extends ParserRuleContext {
		public ParametroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametro; }
	 
		public ParametroContext() { }
		public void copyFrom(ParametroContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParameterContext extends ParametroContext {
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public ParameterContext(ParametroContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterParameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitParameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParametroContext parametro() throws RecognitionException {
		ParametroContext _localctx = new ParametroContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_parametro);
		try {
			_localctx = new ParameterContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(133); tipo();
			setState(134); match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TipoContext extends ParserRuleContext {
		public TipoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo; }
	 
		public TipoContext() { }
		public void copyFrom(TipoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class TipoBooleanContext extends TipoContext {
		public TipoBooleanContext(TipoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterTipoBoolean(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitTipoBoolean(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitTipoBoolean(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TipoFloatContext extends TipoContext {
		public TipoFloatContext(TipoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterTipoFloat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitTipoFloat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitTipoFloat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TipoStringContext extends TipoContext {
		public TipoStringContext(TipoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterTipoString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitTipoString(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitTipoString(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TipoIntContext extends TipoContext {
		public TipoIntContext(TipoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterTipoInt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitTipoInt(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitTipoInt(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TipoContext tipo() throws RecognitionException {
		TipoContext _localctx = new TipoContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_tipo);
		try {
			setState(140);
			switch (_input.LA(1)) {
			case 10:
				_localctx = new TipoIntContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(136); match(10);
				}
				break;
			case 19:
				_localctx = new TipoFloatContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(137); match(19);
				}
				break;
			case 30:
				_localctx = new TipoStringContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(138); match(30);
				}
				break;
			case 17:
				_localctx = new TipoBooleanContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(139); match(17);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComandosContext extends ParserRuleContext {
		public ComandosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comandos; }
	 
		public ComandosContext() { }
		public void copyFrom(ComandosContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ComadoReadContext extends ComandosContext {
		public Lista_idsContext lista_ids() {
			return getRuleContext(Lista_idsContext.class,0);
		}
		public ComadoReadContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComadoRead(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComadoRead(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComadoRead(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoControleContext extends ComandosContext {
		public Comandos_controleContext comandos_controle() {
			return getRuleContext(Comandos_controleContext.class,0);
		}
		public ComandoControleContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoControle(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoControle(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoControle(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoRetornoContext extends ComandosContext {
		public RetornoContext retorno() {
			return getRuleContext(RetornoContext.class,0);
		}
		public ComandoRetornoContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoRetorno(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoRetorno(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoRetorno(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoPrintContext extends ComandosContext {
		public Lista_de_exprContext lista_de_expr() {
			return getRuleContext(Lista_de_exprContext.class,0);
		}
		public ComandoPrintContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoPrint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoPrint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoPrint(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoChamadaFuncaoContext extends ComandosContext {
		public Chamada_de_funcaoContext chamada_de_funcao() {
			return getRuleContext(Chamada_de_funcaoContext.class,0);
		}
		public ComandoChamadaFuncaoContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoChamadaFuncao(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoChamadaFuncao(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoChamadaFuncao(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoExitContext extends ComandosContext {
		public ComandoExitContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoExit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoExit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoExit(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoAtribuicaoContext extends ComandosContext {
		public AtribuicaoContext atribuicao() {
			return getRuleContext(AtribuicaoContext.class,0);
		}
		public ComandoAtribuicaoContext(ComandosContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoAtribuicao(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoAtribuicao(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoAtribuicao(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComandosContext comandos() throws RecognitionException {
		ComandosContext _localctx = new ComandosContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_comandos);
		try {
			setState(160);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				_localctx = new ComandoPrintContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(142); match(24);
				setState(143); match(7);
				setState(144); lista_de_expr();
				setState(145); match(20);
				setState(146); match(28);
				}
				break;

			case 2:
				_localctx = new ComandoAtribuicaoContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(148); atribuicao();
				}
				break;

			case 3:
				_localctx = new ComandoControleContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(149); comandos_controle();
				}
				break;

			case 4:
				_localctx = new ComandoExitContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(150); match(4);
				setState(151); match(28);
				}
				break;

			case 5:
				_localctx = new ComadoReadContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(152); match(1);
				setState(153); match(7);
				setState(154); lista_ids();
				setState(155); match(20);
				setState(156); match(28);
				}
				break;

			case 6:
				_localctx = new ComandoChamadaFuncaoContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(158); chamada_de_funcao();
				}
				break;

			case 7:
				_localctx = new ComandoRetornoContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(159); retorno();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Chamada_de_funcaoContext extends ParserRuleContext {
		public Chamada_de_funcaoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_chamada_de_funcao; }
	 
		public Chamada_de_funcaoContext() { }
		public void copyFrom(Chamada_de_funcaoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ChamadaFuncaoContext extends Chamada_de_funcaoContext {
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public Lista_de_exprContext lista_de_expr() {
			return getRuleContext(Lista_de_exprContext.class,0);
		}
		public ChamadaFuncaoContext(Chamada_de_funcaoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterChamadaFuncao(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitChamadaFuncao(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitChamadaFuncao(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Chamada_de_funcaoContext chamada_de_funcao() throws RecognitionException {
		Chamada_de_funcaoContext _localctx = new Chamada_de_funcaoContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_chamada_de_funcao);
		try {
			_localctx = new ChamadaFuncaoContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(162); match(ID);
			setState(163); match(7);
			setState(164); lista_de_expr();
			setState(165); match(20);
			setState(166); match(28);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Chamada_de_funcao_aninhadaContext extends ParserRuleContext {
		public Chamada_de_funcao_aninhadaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_chamada_de_funcao_aninhada; }
	 
		public Chamada_de_funcao_aninhadaContext() { }
		public void copyFrom(Chamada_de_funcao_aninhadaContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ChamadaFuncaoAninhadaContext extends Chamada_de_funcao_aninhadaContext {
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public Lista_de_exprContext lista_de_expr() {
			return getRuleContext(Lista_de_exprContext.class,0);
		}
		public ChamadaFuncaoAninhadaContext(Chamada_de_funcao_aninhadaContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterChamadaFuncaoAninhada(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitChamadaFuncaoAninhada(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitChamadaFuncaoAninhada(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Chamada_de_funcao_aninhadaContext chamada_de_funcao_aninhada() throws RecognitionException {
		Chamada_de_funcao_aninhadaContext _localctx = new Chamada_de_funcao_aninhadaContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_chamada_de_funcao_aninhada);
		try {
			_localctx = new ChamadaFuncaoAninhadaContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(168); match(ID);
			setState(169); match(7);
			setState(170); lista_de_expr();
			setState(171); match(20);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Comando_elseContext extends ParserRuleContext {
		public Comando_elseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comando_else; }
	 
		public Comando_elseContext() { }
		public void copyFrom(Comando_elseContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ControleElseContext extends Comando_elseContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public ControleElseContext(Comando_elseContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterControleElse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitControleElse(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitControleElse(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comando_elseContext comando_else() throws RecognitionException {
		Comando_elseContext _localctx = new Comando_elseContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_comando_else);
		int _la;
		try {
			_localctx = new ControleElseContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(173); match(16);
			setState(174); match(15);
			setState(178);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0)) {
				{
				{
				setState(175); comandos();
				}
				}
				setState(180);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(181); match(18);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Step_forContext extends ParserRuleContext {
		public Step_forContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_step_for; }
	 
		public Step_forContext() { }
		public void copyFrom(Step_forContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class StepForContext extends Step_forContext {
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public StepForContext(Step_forContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterStepFor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitStepFor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitStepFor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Step_forContext step_for() throws RecognitionException {
		Step_forContext _localctx = new Step_forContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_step_for);
		try {
			_localctx = new StepForContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(183); match(21);
			setState(184); numero();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Comandos_controleContext extends ParserRuleContext {
		public Comandos_controleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comandos_controle; }
	 
		public Comandos_controleContext() { }
		public void copyFrom(Comandos_controleContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ComandoControleIfContext extends Comandos_controleContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public Comando_elseContext comando_else() {
			return getRuleContext(Comando_elseContext.class,0);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public OprelacionalContext oprelacional() {
			return getRuleContext(OprelacionalContext.class,0);
		}
		public ComandoControleIfContext(Comandos_controleContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoControleIf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoControleIf(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoControleIf(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoControleForContext extends Comandos_controleContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public Step_forContext step_for() {
			return getRuleContext(Step_forContext.class,0);
		}
		public List<NumeroContext> numero() {
			return getRuleContexts(NumeroContext.class);
		}
		public NumeroContext numero(int i) {
			return getRuleContext(NumeroContext.class,i);
		}
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public ComandoControleForContext(Comandos_controleContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoControleFor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoControleFor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoControleFor(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ComandoControleWhileContext extends Comandos_controleContext {
		public ComandosContext comandos(int i) {
			return getRuleContext(ComandosContext.class,i);
		}
		public List<ComandosContext> comandos() {
			return getRuleContexts(ComandosContext.class);
		}
		public OprelacionalContext oprelacional() {
			return getRuleContext(OprelacionalContext.class,0);
		}
		public ComandoControleWhileContext(Comandos_controleContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterComandoControleWhile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitComandoControleWhile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitComandoControleWhile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comandos_controleContext comandos_controle() throws RecognitionException {
		Comandos_controleContext _localctx = new Comandos_controleContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_comandos_controle);
		int _la;
		try {
			setState(234);
			switch (_input.LA(1)) {
			case 9:
				_localctx = new ComandoControleIfContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(186); match(9);
				setState(187); match(7);
				setState(188); oprelacional();
				setState(189); match(20);
				setState(190); match(15);
				setState(194);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0)) {
					{
					{
					setState(191); comandos();
					}
					}
					setState(196);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(197); match(18);
				setState(199);
				_la = _input.LA(1);
				if (_la==16) {
					{
					setState(198); comando_else();
					}
				}

				}
				break;
			case 3:
				_localctx = new ComandoControleWhileContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(201); match(3);
				setState(202); match(7);
				setState(203); oprelacional();
				setState(204); match(20);
				setState(205); match(15);
				setState(209);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0)) {
					{
					{
					setState(206); comandos();
					}
					}
					setState(211);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(212); match(18);
				}
				break;
			case 23:
				_localctx = new ComandoControleForContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(214); match(23);
				setState(215); match(7);
				setState(216); identificador();
				setState(217); match(26);
				setState(218); numero();
				setState(219); match(8);
				setState(220); numero();
				setState(222);
				_la = _input.LA(1);
				if (_la==21) {
					{
					setState(221); step_for();
					}
				}

				setState(224); match(20);
				setState(225); match(15);
				setState(229);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 3) | (1L << 4) | (1L << 9) | (1L << 23) | (1L << 24) | (1L << 27) | (1L << ID))) != 0)) {
					{
					{
					setState(226); comandos();
					}
					}
					setState(231);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(232); match(18);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtribuicaoContext extends ParserRuleContext {
		public AtribuicaoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atribuicao; }
	 
		public AtribuicaoContext() { }
		public void copyFrom(AtribuicaoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AtributionContext extends AtribuicaoContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public AtributionContext(AtribuicaoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterAtribution(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitAtribution(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitAtribution(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtribuicaoContext atribuicao() throws RecognitionException {
		AtribuicaoContext _localctx = new AtribuicaoContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_atribuicao);
		try {
			_localctx = new AtributionContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(236); match(ID);
			setState(237); match(26);
			setState(238); expr(0);
			setState(239); match(28);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaracao_varContext extends ParserRuleContext {
		public Declaracao_varContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaracao_var; }
	 
		public Declaracao_varContext() { }
		public void copyFrom(Declaracao_varContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class VariaveisContext extends Declaracao_varContext {
		public Lista_idsContext lista_ids() {
			return getRuleContext(Lista_idsContext.class,0);
		}
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public VariaveisContext(Declaracao_varContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterVariaveis(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitVariaveis(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitVariaveis(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Declaracao_varContext declaracao_var() throws RecognitionException {
		Declaracao_varContext _localctx = new Declaracao_varContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_declaracao_var);
		try {
			_localctx = new VariaveisContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(241); match(13);
			setState(242); lista_ids();
			setState(243); match(8);
			setState(244); tipo();
			setState(245); match(28);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaracao_constContext extends ParserRuleContext {
		public Declaracao_constContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaracao_const; }
	 
		public Declaracao_constContext() { }
		public void copyFrom(Declaracao_constContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ContantesContext extends Declaracao_constContext {
		public TerminalNode BOOLEAN() { return getToken(trabalhoFinalParte1Parser.BOOLEAN, 0); }
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public TerminalNode STRING() { return getToken(trabalhoFinalParte1Parser.STRING, 0); }
		public TerminalNode NUM() { return getToken(trabalhoFinalParte1Parser.NUM, 0); }
		public ContantesContext(Declaracao_constContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterContantes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitContantes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitContantes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Declaracao_constContext declaracao_const() throws RecognitionException {
		Declaracao_constContext _localctx = new Declaracao_constContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_declaracao_const);
		int _la;
		try {
			_localctx = new ContantesContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(247); tipo();
			setState(248); match(ID);
			setState(249); match(26);
			setState(250);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING) | (1L << BOOLEAN) | (1L << NUM))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			setState(251); match(28);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Lista_idsContext extends ParserRuleContext {
		public Lista_idsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lista_ids; }
	 
		public Lista_idsContext() { }
		public void copyFrom(Lista_idsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ListaIdsIDContext extends Lista_idsContext {
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public ListaIdsIDContext(Lista_idsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterListaIdsID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitListaIdsID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitListaIdsID(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ListaIdsContext extends Lista_idsContext {
		public Lista_idsContext lista_ids() {
			return getRuleContext(Lista_idsContext.class,0);
		}
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public ListaIdsContext(Lista_idsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterListaIds(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitListaIds(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitListaIds(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Lista_idsContext lista_ids() throws RecognitionException {
		Lista_idsContext _localctx = new Lista_idsContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_lista_ids);
		try {
			setState(257);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				_localctx = new ListaIdsContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(253); match(ID);
				setState(254); match(2);
				setState(255); lista_ids();
				}
				break;

			case 2:
				_localctx = new ListaIdsIDContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(256); match(ID);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public int _p;
		public ExprContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public ExprContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
			this._p = ctx._p;
		}
	}
	public static class ExprMultdivContext extends ExprContext {
		public ExprContext v1;
		public Token s;
		public ExprContext v2;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprMultdivContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExprMultdiv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExprMultdiv(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExprMultdiv(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprNotContext extends ExprContext {
		public OpnotContext opnot() {
			return getRuleContext(OpnotContext.class,0);
		}
		public ExprNotContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExprNot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExprNot(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExprNot(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprParenteseContext extends ExprContext {
		public ParenteseContext parentese() {
			return getRuleContext(ParenteseContext.class,0);
		}
		public ExprParenteseContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExprParentese(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExprParentese(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExprParentese(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprMinusContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExprMinusContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExprMinus(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExprMinus(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExprMinus(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprSomasubContext extends ExprContext {
		public ExprContext v1;
		public Token s;
		public ExprContext v2;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprSomasubContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterExprSomasub(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitExprSomasub(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitExprSomasub(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState, _p);
		ExprContext _prevctx = _localctx;
		int _startState = 38;
		enterRecursionRule(_localctx, RULE_expr);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(264);
			switch (_input.LA(1)) {
			case 5:
				{
				_localctx = new ExprMinusContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(260); match(5);
				setState(261); expr(3);
				}
				break;
			case 7:
			case STRING:
			case BOOLEAN:
			case ID:
			case NUM:
				{
				_localctx = new ExprParenteseContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(262); parentese();
				}
				break;
			case 35:
				{
				_localctx = new ExprNotContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(263); opnot();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(274);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,21,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(272);
					switch ( getInterpreter().adaptivePredict(_input,20,_ctx) ) {
					case 1:
						{
						_localctx = new ExprMultdivContext(new ExprContext(_parentctx, _parentState, _p));
						((ExprMultdivContext)_localctx).v1 = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(266);
						if (!(2 >= _localctx._p)) throw new FailedPredicateException(this, "2 >= $_p");
						setState(267);
						((ExprMultdivContext)_localctx).s = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==6 || _la==31) ) {
							((ExprMultdivContext)_localctx).s = (Token)_errHandler.recoverInline(this);
						}
						consume();
						setState(268); ((ExprMultdivContext)_localctx).v2 = expr(3);
						}
						break;

					case 2:
						{
						_localctx = new ExprSomasubContext(new ExprContext(_parentctx, _parentState, _p));
						((ExprSomasubContext)_localctx).v1 = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(269);
						if (!(1 >= _localctx._p)) throw new FailedPredicateException(this, "1 >= $_p");
						setState(270);
						((ExprSomasubContext)_localctx).s = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==5 || _la==22) ) {
							((ExprSomasubContext)_localctx).s = (Token)_errHandler.recoverInline(this);
						}
						consume();
						setState(271); ((ExprSomasubContext)_localctx).v2 = expr(2);
						}
						break;
					}
					} 
				}
				setState(276);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,21,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class OpnotContext extends ParserRuleContext {
		public OpnotContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_opnot; }
	 
		public OpnotContext() { }
		public void copyFrom(OpnotContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class OpnotRelacionalContext extends OpnotContext {
		public OprelacionalContext oprelacional() {
			return getRuleContext(OprelacionalContext.class,0);
		}
		public OpnotRelacionalContext(OpnotContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterOpnotRelacional(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitOpnotRelacional(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitOpnotRelacional(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class OpnotFatorContext extends OpnotContext {
		public FatorContext fator() {
			return getRuleContext(FatorContext.class,0);
		}
		public OpnotFatorContext(OpnotContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterOpnotFator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitOpnotFator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitOpnotFator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OpnotContext opnot() throws RecognitionException {
		OpnotContext _localctx = new OpnotContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_opnot);
		try {
			setState(284);
			switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
			case 1:
				_localctx = new OpnotRelacionalContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(277); match(35);
				setState(278); match(7);
				setState(279); oprelacional();
				setState(280); match(20);
				}
				break;

			case 2:
				_localctx = new OpnotFatorContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(282); match(35);
				setState(283); fator();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OprelacionalContext extends ParserRuleContext {
		public OprelacionalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_oprelacional; }
	 
		public OprelacionalContext() { }
		public void copyFrom(OprelacionalContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class OperadorRelacionalExprContext extends OprelacionalContext {
		public OpnotContext opnot() {
			return getRuleContext(OpnotContext.class,0);
		}
		public OperadorRelacionalExprContext(OprelacionalContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterOperadorRelacionalExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitOperadorRelacionalExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitOperadorRelacionalExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class OperadorRelacionalContext extends OprelacionalContext {
		public ExprContext v1;
		public Token s;
		public ExprContext v2;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public OperadorRelacionalContext(OprelacionalContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterOperadorRelacional(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitOperadorRelacional(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitOperadorRelacional(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OprelacionalContext oprelacional() throws RecognitionException {
		OprelacionalContext _localctx = new OprelacionalContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_oprelacional);
		int _la;
		try {
			setState(291);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				_localctx = new OperadorRelacionalContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(286); ((OperadorRelacionalContext)_localctx).v1 = expr(0);
				setState(287);
				((OperadorRelacionalContext)_localctx).s = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 11) | (1L << 12) | (1L << 14) | (1L << 25) | (1L << 29) | (1L << 32) | (1L << 34))) != 0)) ) {
					((OperadorRelacionalContext)_localctx).s = (Token)_errHandler.recoverInline(this);
				}
				consume();
				setState(288); ((OperadorRelacionalContext)_localctx).v2 = expr(0);
				}
				break;

			case 2:
				_localctx = new OperadorRelacionalExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(290); opnot();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParenteseContext extends ParserRuleContext {
		public ParenteseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parentese; }
	 
		public ParenteseContext() { }
		public void copyFrom(ParenteseContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParensContext extends ParenteseContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ParensContext(ParenteseContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterParens(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitParens(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitParens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FatContext extends ParenteseContext {
		public FatorContext fator() {
			return getRuleContext(FatorContext.class,0);
		}
		public FatContext(ParenteseContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParenteseContext parentese() throws RecognitionException {
		ParenteseContext _localctx = new ParenteseContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_parentese);
		try {
			setState(298);
			switch (_input.LA(1)) {
			case 7:
				_localctx = new ParensContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(293); match(7);
				setState(294); expr(0);
				setState(295); match(20);
				}
				break;
			case STRING:
			case BOOLEAN:
			case ID:
			case NUM:
				_localctx = new FatContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(297); fator();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FatorContext extends ParserRuleContext {
		public FatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fator; }
	 
		public FatorContext() { }
		public void copyFrom(FatorContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class FatorNumeroContext extends FatorContext {
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public FatorNumeroContext(FatorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFatorNumero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFatorNumero(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFatorNumero(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FatorIdentificadorContext extends FatorContext {
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public FatorIdentificadorContext(FatorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFatorIdentificador(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFatorIdentificador(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFatorIdentificador(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FatorChamadaFuncaoAninhadaContext extends FatorContext {
		public Chamada_de_funcao_aninhadaContext chamada_de_funcao_aninhada() {
			return getRuleContext(Chamada_de_funcao_aninhadaContext.class,0);
		}
		public FatorChamadaFuncaoAninhadaContext(FatorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFatorChamadaFuncaoAninhada(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFatorChamadaFuncaoAninhada(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFatorChamadaFuncaoAninhada(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FatorBooleanContext extends FatorContext {
		public TerminalNode BOOLEAN() { return getToken(trabalhoFinalParte1Parser.BOOLEAN, 0); }
		public FatorBooleanContext(FatorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFatorBoolean(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFatorBoolean(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFatorBoolean(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FatorStringContext extends FatorContext {
		public TerminalNode STRING() { return getToken(trabalhoFinalParte1Parser.STRING, 0); }
		public FatorStringContext(FatorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterFatorString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitFatorString(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitFatorString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FatorContext fator() throws RecognitionException {
		FatorContext _localctx = new FatorContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_fator);
		try {
			setState(305);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				_localctx = new FatorNumeroContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(300); numero();
				}
				break;

			case 2:
				_localctx = new FatorBooleanContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(301); match(BOOLEAN);
				}
				break;

			case 3:
				_localctx = new FatorChamadaFuncaoAninhadaContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(302); chamada_de_funcao_aninhada();
				}
				break;

			case 4:
				_localctx = new FatorStringContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(303); match(STRING);
				}
				break;

			case 5:
				_localctx = new FatorIdentificadorContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(304); identificador();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumeroContext extends ParserRuleContext {
		public NumeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numero; }
	 
		public NumeroContext() { }
		public void copyFrom(NumeroContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class NumberContext extends NumeroContext {
		public TerminalNode NUM() { return getToken(trabalhoFinalParte1Parser.NUM, 0); }
		public NumberContext(NumeroContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitNumber(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumeroContext numero() throws RecognitionException {
		NumeroContext _localctx = new NumeroContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_numero);
		try {
			_localctx = new NumberContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(307); match(NUM);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentificadorContext extends ParserRuleContext {
		public IdentificadorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identificador; }
	 
		public IdentificadorContext() { }
		public void copyFrom(IdentificadorContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class IdContext extends IdentificadorContext {
		public TerminalNode ID() { return getToken(trabalhoFinalParte1Parser.ID, 0); }
		public IdContext(IdentificadorContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).enterId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof trabalhoFinalParte1Listener ) ((trabalhoFinalParte1Listener)listener).exitId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof trabalhoFinalParte1Visitor ) return ((trabalhoFinalParte1Visitor<? extends T>)visitor).visitId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentificadorContext identificador() throws RecognitionException {
		IdentificadorContext _localctx = new IdentificadorContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_identificador);
		try {
			_localctx = new IdContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(309); match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 19: return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return 2 >= _localctx._p;

		case 1: return 1 >= _localctx._p;
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\uacf5\uee8c\u4f5d\u8b0d\u4a45\u78bd\u1b2f\u3378\3-\u013a\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\3\2\3\2\3\2\3\2\7\2;\n\2\f\2\16\2>\13\2\3\2\7\2A"+
		"\n\2\f\2\16\2D\13\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\7\3M\n\3\f\3\16\3P\13"+
		"\3\3\3\6\3S\n\3\r\3\16\3T\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\7\4"+
		"a\n\4\f\4\16\4d\13\4\3\4\7\4g\n\4\f\4\16\4j\13\4\3\4\3\4\3\5\3\5\5\5p"+
		"\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\7\5\7~\n\7\3\b\3\b"+
		"\3\b\3\b\3\b\3\b\5\b\u0086\n\b\3\t\3\t\3\t\3\n\3\n\3\n\3\n\5\n\u008f\n"+
		"\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3"+
		"\13\3\13\3\13\3\13\3\13\5\13\u00a3\n\13\3\f\3\f\3\f\3\f\3\f\3\f\3\r\3"+
		"\r\3\r\3\r\3\r\3\16\3\16\3\16\7\16\u00b3\n\16\f\16\16\16\u00b6\13\16\3"+
		"\16\3\16\3\17\3\17\3\17\3\20\3\20\3\20\3\20\3\20\3\20\7\20\u00c3\n\20"+
		"\f\20\16\20\u00c6\13\20\3\20\3\20\5\20\u00ca\n\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\7\20\u00d2\n\20\f\20\16\20\u00d5\13\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\5\20\u00e1\n\20\3\20\3\20\3\20\7\20\u00e6"+
		"\n\20\f\20\16\20\u00e9\13\20\3\20\3\20\5\20\u00ed\n\20\3\21\3\21\3\21"+
		"\3\21\3\21\3\22\3\22\3\22\3\22\3\22\3\22\3\23\3\23\3\23\3\23\3\23\3\23"+
		"\3\24\3\24\3\24\3\24\5\24\u0104\n\24\3\25\3\25\3\25\3\25\3\25\5\25\u010b"+
		"\n\25\3\25\3\25\3\25\3\25\3\25\3\25\7\25\u0113\n\25\f\25\16\25\u0116\13"+
		"\25\3\26\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u011f\n\26\3\27\3\27\3\27"+
		"\3\27\3\27\5\27\u0126\n\27\3\30\3\30\3\30\3\30\3\30\5\30\u012d\n\30\3"+
		"\31\3\31\3\31\3\31\3\31\5\31\u0134\n\31\3\32\3\32\3\33\3\33\3\33\2\34"+
		"\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\2\6\4\2\'(*"+
		"*\4\2\b\b!!\4\2\7\7\30\30\b\2\r\16\20\20\33\33\37\37\"\"$$\u0147\2\66"+
		"\3\2\2\2\4G\3\2\2\2\6X\3\2\2\2\bo\3\2\2\2\nq\3\2\2\2\f}\3\2\2\2\16\u0085"+
		"\3\2\2\2\20\u0087\3\2\2\2\22\u008e\3\2\2\2\24\u00a2\3\2\2\2\26\u00a4\3"+
		"\2\2\2\30\u00aa\3\2\2\2\32\u00af\3\2\2\2\34\u00b9\3\2\2\2\36\u00ec\3\2"+
		"\2\2 \u00ee\3\2\2\2\"\u00f3\3\2\2\2$\u00f9\3\2\2\2&\u0103\3\2\2\2(\u010a"+
		"\3\2\2\2*\u011e\3\2\2\2,\u0125\3\2\2\2.\u012c\3\2\2\2\60\u0133\3\2\2\2"+
		"\62\u0135\3\2\2\2\64\u0137\3\2\2\2\66\67\7#\2\2\678\7)\2\28<\7\36\2\2"+
		"9;\5\b\5\2:9\3\2\2\2;>\3\2\2\2<:\3\2\2\2<=\3\2\2\2=B\3\2\2\2><\3\2\2\2"+
		"?A\5\6\4\2@?\3\2\2\2AD\3\2\2\2B@\3\2\2\2BC\3\2\2\2CE\3\2\2\2DB\3\2\2\2"+
		"EF\5\4\3\2F\3\3\2\2\2GH\7&\2\2HI\7\t\2\2IJ\7\26\2\2JN\7\21\2\2KM\5\b\5"+
		"\2LK\3\2\2\2MP\3\2\2\2NL\3\2\2\2NO\3\2\2\2OR\3\2\2\2PN\3\2\2\2QS\5\24"+
		"\13\2RQ\3\2\2\2ST\3\2\2\2TR\3\2\2\2TU\3\2\2\2UV\3\2\2\2VW\7\24\2\2W\5"+
		"\3\2\2\2XY\7)\2\2YZ\7\t\2\2Z[\5\f\7\2[\\\7\26\2\2\\]\7\n\2\2]^\5\22\n"+
		"\2^b\7\21\2\2_a\5\b\5\2`_\3\2\2\2ad\3\2\2\2b`\3\2\2\2bc\3\2\2\2ch\3\2"+
		"\2\2db\3\2\2\2eg\5\24\13\2fe\3\2\2\2gj\3\2\2\2hf\3\2\2\2hi\3\2\2\2ik\3"+
		"\2\2\2jh\3\2\2\2kl\7\24\2\2l\7\3\2\2\2mp\5\"\22\2np\5$\23\2om\3\2\2\2"+
		"on\3\2\2\2p\t\3\2\2\2qr\7\35\2\2rs\7\t\2\2st\5(\25\2tu\7\26\2\2uv\7\36"+
		"\2\2v\13\3\2\2\2wx\5\20\t\2xy\7\4\2\2yz\5\f\7\2z~\3\2\2\2{~\5\20\t\2|"+
		"~\3\2\2\2}w\3\2\2\2}{\3\2\2\2}|\3\2\2\2~\r\3\2\2\2\177\u0080\5(\25\2\u0080"+
		"\u0081\7\4\2\2\u0081\u0082\5\16\b\2\u0082\u0086\3\2\2\2\u0083\u0086\5"+
		"(\25\2\u0084\u0086\3\2\2\2\u0085\177\3\2\2\2\u0085\u0083\3\2\2\2\u0085"+
		"\u0084\3\2\2\2\u0086\17\3\2\2\2\u0087\u0088\5\22\n\2\u0088\u0089\7)\2"+
		"\2\u0089\21\3\2\2\2\u008a\u008f\7\f\2\2\u008b\u008f\7\25\2\2\u008c\u008f"+
		"\7 \2\2\u008d\u008f\7\23\2\2\u008e\u008a\3\2\2\2\u008e\u008b\3\2\2\2\u008e"+
		"\u008c\3\2\2\2\u008e\u008d\3\2\2\2\u008f\23\3\2\2\2\u0090\u0091\7\32\2"+
		"\2\u0091\u0092\7\t\2\2\u0092\u0093\5\16\b\2\u0093\u0094\7\26\2\2\u0094"+
		"\u0095\7\36\2\2\u0095\u00a3\3\2\2\2\u0096\u00a3\5 \21\2\u0097\u00a3\5"+
		"\36\20\2\u0098\u0099\7\6\2\2\u0099\u00a3\7\36\2\2\u009a\u009b\7\3\2\2"+
		"\u009b\u009c\7\t\2\2\u009c\u009d\5&\24\2\u009d\u009e\7\26\2\2\u009e\u009f"+
		"\7\36\2\2\u009f\u00a3\3\2\2\2\u00a0\u00a3\5\26\f\2\u00a1\u00a3\5\n\6\2"+
		"\u00a2\u0090\3\2\2\2\u00a2\u0096\3\2\2\2\u00a2\u0097\3\2\2\2\u00a2\u0098"+
		"\3\2\2\2\u00a2\u009a\3\2\2\2\u00a2\u00a0\3\2\2\2\u00a2\u00a1\3\2\2\2\u00a3"+
		"\25\3\2\2\2\u00a4\u00a5\7)\2\2\u00a5\u00a6\7\t\2\2\u00a6\u00a7\5\16\b"+
		"\2\u00a7\u00a8\7\26\2\2\u00a8\u00a9\7\36\2\2\u00a9\27\3\2\2\2\u00aa\u00ab"+
		"\7)\2\2\u00ab\u00ac\7\t\2\2\u00ac\u00ad\5\16\b\2\u00ad\u00ae\7\26\2\2"+
		"\u00ae\31\3\2\2\2\u00af\u00b0\7\22\2\2\u00b0\u00b4\7\21\2\2\u00b1\u00b3"+
		"\5\24\13\2\u00b2\u00b1\3\2\2\2\u00b3\u00b6\3\2\2\2\u00b4\u00b2\3\2\2\2"+
		"\u00b4\u00b5\3\2\2\2\u00b5\u00b7\3\2\2\2\u00b6\u00b4\3\2\2\2\u00b7\u00b8"+
		"\7\24\2\2\u00b8\33\3\2\2\2\u00b9\u00ba\7\27\2\2\u00ba\u00bb\5\62\32\2"+
		"\u00bb\35\3\2\2\2\u00bc\u00bd\7\13\2\2\u00bd\u00be\7\t\2\2\u00be\u00bf"+
		"\5,\27\2\u00bf\u00c0\7\26\2\2\u00c0\u00c4\7\21\2\2\u00c1\u00c3\5\24\13"+
		"\2\u00c2\u00c1\3\2\2\2\u00c3\u00c6\3\2\2\2\u00c4\u00c2\3\2\2\2\u00c4\u00c5"+
		"\3\2\2\2\u00c5\u00c7\3\2\2\2\u00c6\u00c4\3\2\2\2\u00c7\u00c9\7\24\2\2"+
		"\u00c8\u00ca\5\32\16\2\u00c9\u00c8\3\2\2\2\u00c9\u00ca\3\2\2\2\u00ca\u00ed"+
		"\3\2\2\2\u00cb\u00cc\7\5\2\2\u00cc\u00cd\7\t\2\2\u00cd\u00ce\5,\27\2\u00ce"+
		"\u00cf\7\26\2\2\u00cf\u00d3\7\21\2\2\u00d0\u00d2\5\24\13\2\u00d1\u00d0"+
		"\3\2\2\2\u00d2\u00d5\3\2\2\2\u00d3\u00d1\3\2\2\2\u00d3\u00d4\3\2\2\2\u00d4"+
		"\u00d6\3\2\2\2\u00d5\u00d3\3\2\2\2\u00d6\u00d7\7\24\2\2\u00d7\u00ed\3"+
		"\2\2\2\u00d8\u00d9\7\31\2\2\u00d9\u00da\7\t\2\2\u00da\u00db\5\64\33\2"+
		"\u00db\u00dc\7\34\2\2\u00dc\u00dd\5\62\32\2\u00dd\u00de\7\n\2\2\u00de"+
		"\u00e0\5\62\32\2\u00df\u00e1\5\34\17\2\u00e0\u00df\3\2\2\2\u00e0\u00e1"+
		"\3\2\2\2\u00e1\u00e2\3\2\2\2\u00e2\u00e3\7\26\2\2\u00e3\u00e7\7\21\2\2"+
		"\u00e4\u00e6\5\24\13\2\u00e5\u00e4\3\2\2\2\u00e6\u00e9\3\2\2\2\u00e7\u00e5"+
		"\3\2\2\2\u00e7\u00e8\3\2\2\2\u00e8\u00ea\3\2\2\2\u00e9\u00e7\3\2\2\2\u00ea"+
		"\u00eb\7\24\2\2\u00eb\u00ed\3\2\2\2\u00ec\u00bc\3\2\2\2\u00ec\u00cb\3"+
		"\2\2\2\u00ec\u00d8\3\2\2\2\u00ed\37\3\2\2\2\u00ee\u00ef\7)\2\2\u00ef\u00f0"+
		"\7\34\2\2\u00f0\u00f1\5(\25\2\u00f1\u00f2\7\36\2\2\u00f2!\3\2\2\2\u00f3"+
		"\u00f4\7\17\2\2\u00f4\u00f5\5&\24\2\u00f5\u00f6\7\n\2\2\u00f6\u00f7\5"+
		"\22\n\2\u00f7\u00f8\7\36\2\2\u00f8#\3\2\2\2\u00f9\u00fa\5\22\n\2\u00fa"+
		"\u00fb\7)\2\2\u00fb\u00fc\7\34\2\2\u00fc\u00fd\t\2\2\2\u00fd\u00fe\7\36"+
		"\2\2\u00fe%\3\2\2\2\u00ff\u0100\7)\2\2\u0100\u0101\7\4\2\2\u0101\u0104"+
		"\5&\24\2\u0102\u0104\7)\2\2\u0103\u00ff\3\2\2\2\u0103\u0102\3\2\2\2\u0104"+
		"\'\3\2\2\2\u0105\u0106\b\25\1\2\u0106\u0107\7\7\2\2\u0107\u010b\5(\25"+
		"\2\u0108\u010b\5.\30\2\u0109\u010b\5*\26\2\u010a\u0105\3\2\2\2\u010a\u0108"+
		"\3\2\2\2\u010a\u0109\3\2\2\2\u010b\u0114\3\2\2\2\u010c\u010d\6\25\2\3"+
		"\u010d\u010e\t\3\2\2\u010e\u0113\5(\25\2\u010f\u0110\6\25\3\3\u0110\u0111"+
		"\t\4\2\2\u0111\u0113\5(\25\2\u0112\u010c\3\2\2\2\u0112\u010f\3\2\2\2\u0113"+
		"\u0116\3\2\2\2\u0114\u0112\3\2\2\2\u0114\u0115\3\2\2\2\u0115)\3\2\2\2"+
		"\u0116\u0114\3\2\2\2\u0117\u0118\7%\2\2\u0118\u0119\7\t\2\2\u0119\u011a"+
		"\5,\27\2\u011a\u011b\7\26\2\2\u011b\u011f\3\2\2\2\u011c\u011d\7%\2\2\u011d"+
		"\u011f\5\60\31\2\u011e\u0117\3\2\2\2\u011e\u011c\3\2\2\2\u011f+\3\2\2"+
		"\2\u0120\u0121\5(\25\2\u0121\u0122\t\5\2\2\u0122\u0123\5(\25\2\u0123\u0126"+
		"\3\2\2\2\u0124\u0126\5*\26\2\u0125\u0120\3\2\2\2\u0125\u0124\3\2\2\2\u0126"+
		"-\3\2\2\2\u0127\u0128\7\t\2\2\u0128\u0129\5(\25\2\u0129\u012a\7\26\2\2"+
		"\u012a\u012d\3\2\2\2\u012b\u012d\5\60\31\2\u012c\u0127\3\2\2\2\u012c\u012b"+
		"\3\2\2\2\u012d/\3\2\2\2\u012e\u0134\5\62\32\2\u012f\u0134\7(\2\2\u0130"+
		"\u0134\5\30\r\2\u0131\u0134\7\'\2\2\u0132\u0134\5\64\33\2\u0133\u012e"+
		"\3\2\2\2\u0133\u012f\3\2\2\2\u0133\u0130\3\2\2\2\u0133\u0131\3\2\2\2\u0133"+
		"\u0132\3\2\2\2\u0134\61\3\2\2\2\u0135\u0136\7*\2\2\u0136\63\3\2\2\2\u0137"+
		"\u0138\7)\2\2\u0138\65\3\2\2\2\34<BNTbho}\u0085\u008e\u00a2\u00b4\u00c4"+
		"\u00c9\u00d3\u00e0\u00e7\u00ec\u0103\u010a\u0112\u0114\u011e\u0125\u012c"+
		"\u0133";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}