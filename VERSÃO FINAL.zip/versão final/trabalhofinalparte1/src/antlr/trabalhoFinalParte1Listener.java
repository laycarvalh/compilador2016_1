package antlr;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link trabalhoFinalParte1Parser}.
 */
public interface trabalhoFinalParte1Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#controleElse}.
	 * @param ctx the parse tree
	 */
	void enterControleElse(@NotNull trabalhoFinalParte1Parser.ControleElseContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#controleElse}.
	 * @param ctx the parse tree
	 */
	void exitControleElse(@NotNull trabalhoFinalParte1Parser.ControleElseContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#tipoString}.
	 * @param ctx the parse tree
	 */
	void enterTipoString(@NotNull trabalhoFinalParte1Parser.TipoStringContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoString}.
	 * @param ctx the parse tree
	 */
	void exitTipoString(@NotNull trabalhoFinalParte1Parser.TipoStringContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comadoRead}.
	 * @param ctx the parse tree
	 */
	void enterComadoRead(@NotNull trabalhoFinalParte1Parser.ComadoReadContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comadoRead}.
	 * @param ctx the parse tree
	 */
	void exitComadoRead(@NotNull trabalhoFinalParte1Parser.ComadoReadContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Contantes}.
	 * @param ctx the parse tree
	 */
	void enterContantes(@NotNull trabalhoFinalParte1Parser.ContantesContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Contantes}.
	 * @param ctx the parse tree
	 */
	void exitContantes(@NotNull trabalhoFinalParte1Parser.ContantesContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#opnotRelacional}.
	 * @param ctx the parse tree
	 */
	void enterOpnotRelacional(@NotNull trabalhoFinalParte1Parser.OpnotRelacionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#opnotRelacional}.
	 * @param ctx the parse tree
	 */
	void exitOpnotRelacional(@NotNull trabalhoFinalParte1Parser.OpnotRelacionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoChamadaFuncao}.
	 * @param ctx the parse tree
	 */
	void enterComandoChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoChamadaFuncao}.
	 * @param ctx the parse tree
	 */
	void exitComandoChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#opnotFator}.
	 * @param ctx the parse tree
	 */
	void enterOpnotFator(@NotNull trabalhoFinalParte1Parser.OpnotFatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#opnotFator}.
	 * @param ctx the parse tree
	 */
	void exitOpnotFator(@NotNull trabalhoFinalParte1Parser.OpnotFatorContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#tipoBoolean}.
	 * @param ctx the parse tree
	 */
	void enterTipoBoolean(@NotNull trabalhoFinalParte1Parser.TipoBooleanContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoBoolean}.
	 * @param ctx the parse tree
	 */
	void exitTipoBoolean(@NotNull trabalhoFinalParte1Parser.TipoBooleanContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Body}.
	 * @param ctx the parse tree
	 */
	void enterBody(@NotNull trabalhoFinalParte1Parser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Body}.
	 * @param ctx the parse tree
	 */
	void exitBody(@NotNull trabalhoFinalParte1Parser.BodyContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Parens}.
	 * @param ctx the parse tree
	 */
	void enterParens(@NotNull trabalhoFinalParte1Parser.ParensContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Parens}.
	 * @param ctx the parse tree
	 */
	void exitParens(@NotNull trabalhoFinalParte1Parser.ParensContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Param}.
	 * @param ctx the parse tree
	 */
	void enterParam(@NotNull trabalhoFinalParte1Parser.ParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Param}.
	 * @param ctx the parse tree
	 */
	void exitParam(@NotNull trabalhoFinalParte1Parser.ParamContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#listaIds}.
	 * @param ctx the parse tree
	 */
	void enterListaIds(@NotNull trabalhoFinalParte1Parser.ListaIdsContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#listaIds}.
	 * @param ctx the parse tree
	 */
	void exitListaIds(@NotNull trabalhoFinalParte1Parser.ListaIdsContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(@NotNull trabalhoFinalParte1Parser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(@NotNull trabalhoFinalParte1Parser.NumberContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#fatorNumero}.
	 * @param ctx the parse tree
	 */
	void enterFatorNumero(@NotNull trabalhoFinalParte1Parser.FatorNumeroContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorNumero}.
	 * @param ctx the parse tree
	 */
	void exitFatorNumero(@NotNull trabalhoFinalParte1Parser.FatorNumeroContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#StepFor}.
	 * @param ctx the parse tree
	 */
	void enterStepFor(@NotNull trabalhoFinalParte1Parser.StepForContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#StepFor}.
	 * @param ctx the parse tree
	 */
	void exitStepFor(@NotNull trabalhoFinalParte1Parser.StepForContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleFor}.
	 * @param ctx the parse tree
	 */
	void enterComandoControleFor(@NotNull trabalhoFinalParte1Parser.ComandoControleForContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleFor}.
	 * @param ctx the parse tree
	 */
	void exitComandoControleFor(@NotNull trabalhoFinalParte1Parser.ComandoControleForContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#fatorIdentificador}.
	 * @param ctx the parse tree
	 */
	void enterFatorIdentificador(@NotNull trabalhoFinalParte1Parser.FatorIdentificadorContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorIdentificador}.
	 * @param ctx the parse tree
	 */
	void exitFatorIdentificador(@NotNull trabalhoFinalParte1Parser.FatorIdentificadorContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#fatorBoolean}.
	 * @param ctx the parse tree
	 */
	void enterFatorBoolean(@NotNull trabalhoFinalParte1Parser.FatorBooleanContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorBoolean}.
	 * @param ctx the parse tree
	 */
	void exitFatorBoolean(@NotNull trabalhoFinalParte1Parser.FatorBooleanContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Return}.
	 * @param ctx the parse tree
	 */
	void enterReturn(@NotNull trabalhoFinalParte1Parser.ReturnContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Return}.
	 * @param ctx the parse tree
	 */
	void exitReturn(@NotNull trabalhoFinalParte1Parser.ReturnContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#exprNot}.
	 * @param ctx the parse tree
	 */
	void enterExprNot(@NotNull trabalhoFinalParte1Parser.ExprNotContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#exprNot}.
	 * @param ctx the parse tree
	 */
	void exitExprNot(@NotNull trabalhoFinalParte1Parser.ExprNotContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Id}.
	 * @param ctx the parse tree
	 */
	void enterId(@NotNull trabalhoFinalParte1Parser.IdContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Id}.
	 * @param ctx the parse tree
	 */
	void exitId(@NotNull trabalhoFinalParte1Parser.IdContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#listaParam}.
	 * @param ctx the parse tree
	 */
	void enterListaParam(@NotNull trabalhoFinalParte1Parser.ListaParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#listaParam}.
	 * @param ctx the parse tree
	 */
	void exitListaParam(@NotNull trabalhoFinalParte1Parser.ListaParamContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacional}.
	 * @param ctx the parse tree
	 */
	void enterOperadorRelacional(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacional}.
	 * @param ctx the parse tree
	 */
	void exitOperadorRelacional(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoAtribuicao}.
	 * @param ctx the parse tree
	 */
	void enterComandoAtribuicao(@NotNull trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoAtribuicao}.
	 * @param ctx the parse tree
	 */
	void exitComandoAtribuicao(@NotNull trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#tipoInt}.
	 * @param ctx the parse tree
	 */
	void enterTipoInt(@NotNull trabalhoFinalParte1Parser.TipoIntContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoInt}.
	 * @param ctx the parse tree
	 */
	void exitTipoInt(@NotNull trabalhoFinalParte1Parser.TipoIntContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#exprSomasub}.
	 * @param ctx the parse tree
	 */
	void enterExprSomasub(@NotNull trabalhoFinalParte1Parser.ExprSomasubContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#exprSomasub}.
	 * @param ctx the parse tree
	 */
	void exitExprSomasub(@NotNull trabalhoFinalParte1Parser.ExprSomasubContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#listaIdsID}.
	 * @param ctx the parse tree
	 */
	void enterListaIdsID(@NotNull trabalhoFinalParte1Parser.ListaIdsIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#listaIdsID}.
	 * @param ctx the parse tree
	 */
	void exitListaIdsID(@NotNull trabalhoFinalParte1Parser.ListaIdsIDContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoRetorno}.
	 * @param ctx the parse tree
	 */
	void enterComandoRetorno(@NotNull trabalhoFinalParte1Parser.ComandoRetornoContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoRetorno}.
	 * @param ctx the parse tree
	 */
	void exitComandoRetorno(@NotNull trabalhoFinalParte1Parser.ComandoRetornoContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 */
	void enterChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 */
	void exitChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleWhile}.
	 * @param ctx the parse tree
	 */
	void enterComandoControleWhile(@NotNull trabalhoFinalParte1Parser.ComandoControleWhileContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleWhile}.
	 * @param ctx the parse tree
	 */
	void exitComandoControleWhile(@NotNull trabalhoFinalParte1Parser.ComandoControleWhileContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncao}.
	 * @param ctx the parse tree
	 */
	void enterChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncao}.
	 * @param ctx the parse tree
	 */
	void exitChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#fatorString}.
	 * @param ctx the parse tree
	 */
	void enterFatorString(@NotNull trabalhoFinalParte1Parser.FatorStringContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorString}.
	 * @param ctx the parse tree
	 */
	void exitFatorString(@NotNull trabalhoFinalParte1Parser.FatorStringContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Main}.
	 * @param ctx the parse tree
	 */
	void enterMain(@NotNull trabalhoFinalParte1Parser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Main}.
	 * @param ctx the parse tree
	 */
	void exitMain(@NotNull trabalhoFinalParte1Parser.MainContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControle}.
	 * @param ctx the parse tree
	 */
	void enterComandoControle(@NotNull trabalhoFinalParte1Parser.ComandoControleContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControle}.
	 * @param ctx the parse tree
	 */
	void exitComandoControle(@NotNull trabalhoFinalParte1Parser.ComandoControleContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoVariaveis}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracaoVariaveis(@NotNull trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoVariaveis}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracaoVariaveis(@NotNull trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#tipoFloat}.
	 * @param ctx the parse tree
	 */
	void enterTipoFloat(@NotNull trabalhoFinalParte1Parser.TipoFloatContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoFloat}.
	 * @param ctx the parse tree
	 */
	void exitTipoFloat(@NotNull trabalhoFinalParte1Parser.TipoFloatContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#emptyParam}.
	 * @param ctx the parse tree
	 */
	void enterEmptyParam(@NotNull trabalhoFinalParte1Parser.EmptyParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#emptyParam}.
	 * @param ctx the parse tree
	 */
	void exitEmptyParam(@NotNull trabalhoFinalParte1Parser.EmptyParamContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(@NotNull trabalhoFinalParte1Parser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(@NotNull trabalhoFinalParte1Parser.ExpressionContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoExit}.
	 * @param ctx the parse tree
	 */
	void enterComandoExit(@NotNull trabalhoFinalParte1Parser.ComandoExitContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoExit}.
	 * @param ctx the parse tree
	 */
	void exitComandoExit(@NotNull trabalhoFinalParte1Parser.ComandoExitContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Parameter}.
	 * @param ctx the parse tree
	 */
	void enterParameter(@NotNull trabalhoFinalParte1Parser.ParameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Parameter}.
	 * @param ctx the parse tree
	 */
	void exitParameter(@NotNull trabalhoFinalParte1Parser.ParameterContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Fat}.
	 * @param ctx the parse tree
	 */
	void enterFat(@NotNull trabalhoFinalParte1Parser.FatContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Fat}.
	 * @param ctx the parse tree
	 */
	void exitFat(@NotNull trabalhoFinalParte1Parser.FatContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleIf}.
	 * @param ctx the parse tree
	 */
	void enterComandoControleIf(@NotNull trabalhoFinalParte1Parser.ComandoControleIfContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleIf}.
	 * @param ctx the parse tree
	 */
	void exitComandoControleIf(@NotNull trabalhoFinalParte1Parser.ComandoControleIfContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(@NotNull trabalhoFinalParte1Parser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(@NotNull trabalhoFinalParte1Parser.FunctionContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoContantes}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracaoContantes(@NotNull trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoContantes}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracaoContantes(@NotNull trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacionalExpr}.
	 * @param ctx the parse tree
	 */
	void enterOperadorRelacionalExpr(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacionalExpr}.
	 * @param ctx the parse tree
	 */
	void exitOperadorRelacionalExpr(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#fatorChamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 */
	void enterFatorChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorChamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 */
	void exitFatorChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#exprMinus}.
	 * @param ctx the parse tree
	 */
	void enterExprMinus(@NotNull trabalhoFinalParte1Parser.ExprMinusContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#exprMinus}.
	 * @param ctx the parse tree
	 */
	void exitExprMinus(@NotNull trabalhoFinalParte1Parser.ExprMinusContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#comandoPrint}.
	 * @param ctx the parse tree
	 */
	void enterComandoPrint(@NotNull trabalhoFinalParte1Parser.ComandoPrintContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoPrint}.
	 * @param ctx the parse tree
	 */
	void exitComandoPrint(@NotNull trabalhoFinalParte1Parser.ComandoPrintContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#emptyExpression}.
	 * @param ctx the parse tree
	 */
	void enterEmptyExpression(@NotNull trabalhoFinalParte1Parser.EmptyExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#emptyExpression}.
	 * @param ctx the parse tree
	 */
	void exitEmptyExpression(@NotNull trabalhoFinalParte1Parser.EmptyExpressionContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Atribution}.
	 * @param ctx the parse tree
	 */
	void enterAtribution(@NotNull trabalhoFinalParte1Parser.AtributionContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Atribution}.
	 * @param ctx the parse tree
	 */
	void exitAtribution(@NotNull trabalhoFinalParte1Parser.AtributionContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#exprMultdiv}.
	 * @param ctx the parse tree
	 */
	void enterExprMultdiv(@NotNull trabalhoFinalParte1Parser.ExprMultdivContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#exprMultdiv}.
	 * @param ctx the parse tree
	 */
	void exitExprMultdiv(@NotNull trabalhoFinalParte1Parser.ExprMultdivContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#listExpression}.
	 * @param ctx the parse tree
	 */
	void enterListExpression(@NotNull trabalhoFinalParte1Parser.ListExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#listExpression}.
	 * @param ctx the parse tree
	 */
	void exitListExpression(@NotNull trabalhoFinalParte1Parser.ListExpressionContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#exprParentese}.
	 * @param ctx the parse tree
	 */
	void enterExprParentese(@NotNull trabalhoFinalParte1Parser.ExprParenteseContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#exprParentese}.
	 * @param ctx the parse tree
	 */
	void exitExprParentese(@NotNull trabalhoFinalParte1Parser.ExprParenteseContext ctx);

	/**
	 * Enter a parse tree produced by {@link trabalhoFinalParte1Parser#Variaveis}.
	 * @param ctx the parse tree
	 */
	void enterVariaveis(@NotNull trabalhoFinalParte1Parser.VariaveisContext ctx);
	/**
	 * Exit a parse tree produced by {@link trabalhoFinalParte1Parser#Variaveis}.
	 * @param ctx the parse tree
	 */
	void exitVariaveis(@NotNull trabalhoFinalParte1Parser.VariaveisContext ctx);
}