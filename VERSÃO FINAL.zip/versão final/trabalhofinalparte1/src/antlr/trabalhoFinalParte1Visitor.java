package antlr;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link trabalhoFinalParte1Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface trabalhoFinalParte1Visitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#controleElse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControleElse(@NotNull trabalhoFinalParte1Parser.ControleElseContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoString}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipoString(@NotNull trabalhoFinalParte1Parser.TipoStringContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comadoRead}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComadoRead(@NotNull trabalhoFinalParte1Parser.ComadoReadContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Contantes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContantes(@NotNull trabalhoFinalParte1Parser.ContantesContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#opnotRelacional}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpnotRelacional(@NotNull trabalhoFinalParte1Parser.OpnotRelacionalContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoChamadaFuncao}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ComandoChamadaFuncaoContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#opnotFator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpnotFator(@NotNull trabalhoFinalParte1Parser.OpnotFatorContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoBoolean}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipoBoolean(@NotNull trabalhoFinalParte1Parser.TipoBooleanContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(@NotNull trabalhoFinalParte1Parser.BodyContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Parens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParens(@NotNull trabalhoFinalParte1Parser.ParensContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParam(@NotNull trabalhoFinalParte1Parser.ParamContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#listaIds}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListaIds(@NotNull trabalhoFinalParte1Parser.ListaIdsContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(@NotNull trabalhoFinalParte1Parser.NumberContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorNumero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFatorNumero(@NotNull trabalhoFinalParte1Parser.FatorNumeroContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#StepFor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStepFor(@NotNull trabalhoFinalParte1Parser.StepForContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleFor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoControleFor(@NotNull trabalhoFinalParte1Parser.ComandoControleForContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorIdentificador}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFatorIdentificador(@NotNull trabalhoFinalParte1Parser.FatorIdentificadorContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorBoolean}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFatorBoolean(@NotNull trabalhoFinalParte1Parser.FatorBooleanContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Return}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn(@NotNull trabalhoFinalParte1Parser.ReturnContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#exprNot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprNot(@NotNull trabalhoFinalParte1Parser.ExprNotContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId(@NotNull trabalhoFinalParte1Parser.IdContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#listaParam}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListaParam(@NotNull trabalhoFinalParte1Parser.ListaParamContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacional}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperadorRelacional(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoAtribuicao}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoAtribuicao(@NotNull trabalhoFinalParte1Parser.ComandoAtribuicaoContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoInt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipoInt(@NotNull trabalhoFinalParte1Parser.TipoIntContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#exprSomasub}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprSomasub(@NotNull trabalhoFinalParte1Parser.ExprSomasubContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#listaIdsID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListaIdsID(@NotNull trabalhoFinalParte1Parser.ListaIdsIDContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoRetorno}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoRetorno(@NotNull trabalhoFinalParte1Parser.ComandoRetornoContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoAninhadaContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleWhile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoControleWhile(@NotNull trabalhoFinalParte1Parser.ComandoControleWhileContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#chamadaFuncao}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChamadaFuncao(@NotNull trabalhoFinalParte1Parser.ChamadaFuncaoContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorString}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFatorString(@NotNull trabalhoFinalParte1Parser.FatorStringContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Main}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain(@NotNull trabalhoFinalParte1Parser.MainContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControle}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoControle(@NotNull trabalhoFinalParte1Parser.ComandoControleContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoVariaveis}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaracaoVariaveis(@NotNull trabalhoFinalParte1Parser.DeclaracaoVariaveisContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#tipoFloat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipoFloat(@NotNull trabalhoFinalParte1Parser.TipoFloatContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#emptyParam}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyParam(@NotNull trabalhoFinalParte1Parser.EmptyParamContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(@NotNull trabalhoFinalParte1Parser.ExpressionContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoExit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoExit(@NotNull trabalhoFinalParte1Parser.ComandoExitContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter(@NotNull trabalhoFinalParte1Parser.ParameterContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Fat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFat(@NotNull trabalhoFinalParte1Parser.FatContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoControleIf}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoControleIf(@NotNull trabalhoFinalParte1Parser.ComandoControleIfContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction(@NotNull trabalhoFinalParte1Parser.FunctionContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#declaracaoContantes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaracaoContantes(@NotNull trabalhoFinalParte1Parser.DeclaracaoContantesContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#operadorRelacionalExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperadorRelacionalExpr(@NotNull trabalhoFinalParte1Parser.OperadorRelacionalExprContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#fatorChamadaFuncaoAninhada}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFatorChamadaFuncaoAninhada(@NotNull trabalhoFinalParte1Parser.FatorChamadaFuncaoAninhadaContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#exprMinus}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprMinus(@NotNull trabalhoFinalParte1Parser.ExprMinusContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#comandoPrint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComandoPrint(@NotNull trabalhoFinalParte1Parser.ComandoPrintContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#emptyExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyExpression(@NotNull trabalhoFinalParte1Parser.EmptyExpressionContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Atribution}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtribution(@NotNull trabalhoFinalParte1Parser.AtributionContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#exprMultdiv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprMultdiv(@NotNull trabalhoFinalParte1Parser.ExprMultdivContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#listExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListExpression(@NotNull trabalhoFinalParte1Parser.ListExpressionContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#exprParentese}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprParentese(@NotNull trabalhoFinalParte1Parser.ExprParenteseContext ctx);

	/**
	 * Visit a parse tree produced by {@link trabalhoFinalParte1Parser#Variaveis}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariaveis(@NotNull trabalhoFinalParte1Parser.VariaveisContext ctx);
}